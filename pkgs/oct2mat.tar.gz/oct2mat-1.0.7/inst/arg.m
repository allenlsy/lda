function ph=arg(x)
     ph=angle(x);
