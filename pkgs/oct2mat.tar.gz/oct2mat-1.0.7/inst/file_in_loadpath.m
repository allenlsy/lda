function name=file_in_loadpath(file)
  name=file_in_path(path,file);
  