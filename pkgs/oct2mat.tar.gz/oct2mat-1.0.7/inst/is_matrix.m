function y=is_matrix(x)
	y=isnumeric(x);

