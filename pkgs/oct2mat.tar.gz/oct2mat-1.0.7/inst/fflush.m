function fflush
